require("@nomicfoundation/hardhat-ethers");
require("dotenv").config();

const accounts = process.env.ADMIN_PRIVATE_KEY
  ? [process.env.ADMIN_PRIVATE_KEY]
  : [];

/** @type import('hardhat/config').HardhatUserConfig */
module.exports = {
  solidity: "0.8.19",
  networks: {
    hardhat: {
      // point at a local `hardhat node` if you run one; otherwise in-process
    },
    localhost: {
      url: process.env.RPC_URL || "http://127.0.0.1:8545",
      accounts,
    },
  },
};
